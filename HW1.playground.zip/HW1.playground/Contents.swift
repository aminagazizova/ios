import Foundation

class Car {
    var brand: String
    var model: String
    var year: Int
    
    init(brand: String, model: String, year: Int) {
        self.brand = brand
        self.model = model
        self.year = year
    }
    
    func displayInfo() {
        print("Марка: \(brand), Модель: \(model), Год выпуска: \(year)")
    }
}

class BMW: Car {
    var enginePower: Int
    var fuelConsumption: Double
    
    init(brand: String, model: String, year: Int, enginePower: Int, fuelConsumption: Double) {
        self.enginePower = enginePower
        self.fuelConsumption = fuelConsumption
        super.init(brand: brand, model: model, year: year)
    }
}

// метод создания автомобилей
func createCars() -> [Car] {
    let cars = [
        BMW(brand: "BMW", model: "X5", year: 2020, enginePower: 300, fuelConsumption: 10.5),
        BMW(brand: "Mercedes", model: "Benz C", year: 2016, enginePower: 230, fuelConsumption: 15.2),
        BMW(brand: "BMW", model: "320i", year: 2019, enginePower: 200, fuelConsumption: 8.7),
        BMW(brand: "Mersedes", model: "G 63 AMG", year: 2023, enginePower: 422, fuelConsumption: 9.8)
    ]
    
    return cars
}

// метод создания гонок между парами, определение победителя с помощью лошадиных сил
func startRace(cars: [Car]) {
    for i in 0..<cars.count {
        for j in i+1..<cars.count {
            let car1 = cars[i] as! BMW
            let car2 = cars[j] as! BMW
            
            print("Гонка между \(car1.brand) \(car1.model) и \(car2.brand) \(car2.model):")
            if car1.enginePower > car2.enginePower {
                print("\(car1.brand) \(car1.model) побеждает в гонке.")
            } else if car1.enginePower < car2.enginePower {
                print("\(car2.brand) \(car2.model) побеждает в гонке.")
            } else {
                print("Ничья между \(car1.brand) \(car1.model) и \(car2.brand) \(car2.model).")
            }
        }
    }
}

// проверка
let cars = createCars()

startRace(cars: cars)
